let allUsers = [];

const container = document.getElementById("user-container");
const loader = document.getElementById("loader");
const searchInput = document.getElementById("search");

function fetchUserData() {
    container.innerHTML = "";
    loader.classList.remove("hidden");

    fetch("https://jsonplaceholder.typicode.com/users")
        .then(res => {
            if (!res.ok) throw new Error("Failed to fetch users");
            return res.json();
        })
        .then(data => {
            allUsers = data;
            displayUsers(allUsers);
            loader.classList.add("hidden");
        })
        .catch(err => {
            loader.classList.add("hidden");
            container.innerHTML = `<p style="color: red;">${err.message}</p>`;
        });
}

function displayUsers(users) {
    container.innerHTML = "";
    users.forEach(user => {
        const card = document.createElement("div");
        card.className = "user-card";
        card.innerHTML = `
            <h3>${user.name}</h3>
            <p><strong>Email:</strong> ${user.email}</p>
            <p><strong>Phone:</strong> ${user.phone}</p>
            <p><strong>City:</strong> ${user.address.city}</p>
        `;
        container.appendChild(card);
    });
}

function filterUsers() {
    const searchTerm = searchInput.value.toLowerCase();
    const filtered = allUsers.filter(user => user.name.toLowerCase().includes(searchTerm));
    displayUsers(filtered);
}

// Auto load on page open
window.onload = fetchUserData;
